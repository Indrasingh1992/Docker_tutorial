# flask-app-ecs
Simple flask app to be run on ECS
